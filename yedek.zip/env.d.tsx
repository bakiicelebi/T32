declare module '@env' {
    export const API_CATEGORIES_URL: string;
    export const API_BASE_URL: string;
    export const API_CAMPAIGNS_URL: string;
    export const API_STATUS_URL: string;
    export const EMAIL_SERVICE_KEY: string;
    export const EMAIL_TEMPLATE_KEY: string;
    export const EMAIL_PUBLIC_KEY: string;

}