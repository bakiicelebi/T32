import { StyleSheet, Dimensions } from "react-native";


export default StyleSheet.create({
    
})